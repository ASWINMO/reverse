from django.urls import path
from .views import *

urlpatterns = [
    path('userhome/',userView.as_view(),name="uh"),
    path('profile/',ProfileView.as_view(),name="prof"),
    path('addprofile/',AddProfile.as_view(),name="addpro"),


    

    
]
